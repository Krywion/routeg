//
// Created by Maks Krywionek on 06/05/2024.
//

#include "Vertex.h"

Vertex::Vertex(std::string label) : label(std::move(label)) {}